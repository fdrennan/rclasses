library(testthat)
library(UnitTesting)

test_check("UnitTesting")

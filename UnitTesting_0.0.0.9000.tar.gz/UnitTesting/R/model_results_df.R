#' model_results_df
#' @description A toy dataset of model results
'model_results_df'
